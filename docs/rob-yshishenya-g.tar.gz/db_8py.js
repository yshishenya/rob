var db_8py =
[
    [ "backend.db.User", "classbackend_1_1db_1_1User.html", "classbackend_1_1db_1_1User" ],
    [ "get_db", "db_8py.html#a531d50d0e97c20ce2de9118403d355c8", null ],
    [ "init_db", "db_8py.html#aede5ea7cecfbb5e666435bbf5fad8735", null ],
    [ "Base", "db_8py.html#a036b7ab6f207c3287b0668774b089dd0", null ],
    [ "DATABASE_URL", "db_8py.html#a2712f6a35719e12a41eb5c87bffcea74", null ],
    [ "engine", "db_8py.html#a33e6267c091c7fc29397fa9666cd25b5", null ],
    [ "level", "db_8py.html#a12e4627d89ec45bd8387dec506627a0b", null ],
    [ "logger", "db_8py.html#a7bf12892f824b7a3da5c6cb6e4e30ce5", null ],
    [ "POSTGRES_DB", "db_8py.html#a10c4e3657b51825bdb57f8b8e4f51f18", null ],
    [ "POSTGRES_HOST", "db_8py.html#a3f77cd852989af7c147aebe846e4d290", null ],
    [ "POSTGRES_PASSWORD", "db_8py.html#a2328c07abd416fb91dbfb10c33b98b3c", null ],
    [ "POSTGRES_PORT", "db_8py.html#a03c2448ae52310081c8c2299c5a68885", null ],
    [ "POSTGRES_USER", "db_8py.html#a2c81f46a6c0833e0e7d1b21bd816234b", null ],
    [ "SessionLocal", "db_8py.html#a0b318ee468d301d1808f4f6c49ada651", null ]
];