var serper_8py =
[
    [ "gpt_researcher.retrievers.serper.serper.SerperSearch", "classgpt__researcher_1_1retrievers_1_1serper_1_1serper_1_1SerperSearch.html", "classgpt__researcher_1_1retrievers_1_1serper_1_1serper_1_1SerperSearch" ]
];