var llm_8py =
[
    [ "construct_subtopics", "llm_8py.html#a3125e642ba0eba1562845ff7d15ecb08", null ],
    [ "create_chat_completion", "llm_8py.html#aabaadb598e9e86c6e4a0c50627463b95", null ],
    [ "get_llm", "llm_8py.html#a350bb4294397495c506426a2caad2b31", null ]
];