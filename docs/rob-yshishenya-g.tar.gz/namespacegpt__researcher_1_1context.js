var namespacegpt__researcher_1_1context =
[
    [ "compression", "namespacegpt__researcher_1_1context_1_1compression.html", "namespacegpt__researcher_1_1context_1_1compression" ],
    [ "retriever", "namespacegpt__researcher_1_1context_1_1retriever.html", "namespacegpt__researcher_1_1context_1_1retriever" ],
    [ "__all__", "namespacegpt__researcher_1_1context.html#a4faa2b0c0c70150796b5a45732aa6dbf", null ]
];