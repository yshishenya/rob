var costs_8py =
[
    [ "estimate_embedding_cost", "costs_8py.html#a59fa6a66d1cc1d9a1bf6e72c6c933835", null ],
    [ "estimate_llm_cost", "costs_8py.html#a3c3b6e46daf03a6c6eff6af6b7d581a1", null ],
    [ "EMBEDDING_COST", "costs_8py.html#ac851877e589fc31f44a8b28053f69cb3", null ],
    [ "ENCODING_MODEL", "costs_8py.html#a5ded738042198cd2363d7057fcebed3a", null ],
    [ "IMAGE_INFERENCE_COST", "costs_8py.html#aa6c6f6531263d9beca9c84e3c7290e57", null ],
    [ "INPUT_COST_PER_TOKEN", "costs_8py.html#a7001ea5a3cfcc38b054e1f61532d615a", null ],
    [ "OUTPUT_COST_PER_TOKEN", "costs_8py.html#a1f613faeb26205430d23505d18591801", null ]
];