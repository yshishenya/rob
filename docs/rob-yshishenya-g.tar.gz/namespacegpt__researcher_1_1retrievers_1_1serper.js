var namespacegpt__researcher_1_1retrievers_1_1serper =
[
    [ "serper", "namespacegpt__researcher_1_1retrievers_1_1serper_1_1serper.html", "namespacegpt__researcher_1_1retrievers_1_1serper_1_1serper" ]
];