var classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper =
[
    [ "__init__", "classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper.html#a67b8865df0b1e6406fe87daa8c68f657", null ],
    [ "scrape", "classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper.html#abe43b9568308386f0f417517792c5074", null ],
    [ "link", "classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper.html#a90da5467540a10356101c4aeb2af439b", null ],
    [ "session", "classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper.html#a2772460be01c2689081d6272cd804229", null ]
];