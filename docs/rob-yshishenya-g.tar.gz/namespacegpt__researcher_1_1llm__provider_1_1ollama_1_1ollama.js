var namespacegpt__researcher_1_1llm__provider_1_1ollama_1_1ollama =
[
    [ "OllamaProvider", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider" ]
];