var namespacegpt__researcher_1_1llm__provider_1_1ollama =
[
    [ "ollama", "namespacegpt__researcher_1_1llm__provider_1_1ollama_1_1ollama.html", "namespacegpt__researcher_1_1llm__provider_1_1ollama_1_1ollama" ]
];