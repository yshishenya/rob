var classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport =
[
    [ "__init__", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a7281c0a7387d041d3a1592a168632a44", null ],
    [ "_construct_detailed_report", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a34716fb7e8580c57a47ee5230c91d567", null ],
    [ "_generate_subtopic_reports", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a90f2f9d6cde4d8b8f35274937d281c94", null ],
    [ "_get_all_subtopics", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a0535b2e1a13765f0e684d4ac0dbb306f", null ],
    [ "_get_subtopic_report", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#ab4222f0b61a14a6c08c6765f3e337d89", null ],
    [ "_initial_research", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#af6acd4a4ae8dcae11eddeb68fe1bd2f1", null ],
    [ "run", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a1ca617f8321dab09cda55a64ea5a289f", null ],
    [ "config_path", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a221962d4df23d2476a24fcda876d037a", null ],
    [ "existing_headers", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a243d64db7407c3effaafc4ba4055dafb", null ],
    [ "global_context", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a2655bf073543019eefe8c1ae96168f73", null ],
    [ "global_urls", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#ad751ada9bed4490bb6dff1157ac6885c", null ],
    [ "main_task_assistant", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a24bd934498e4ee5c27b336560bc21892", null ],
    [ "query", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a78f09ae4ef42c70ddf577150db317032", null ],
    [ "report_source", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a75f066b7b970c3f96cf6c1c68abda99a", null ],
    [ "report_type", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a1f44e3d7a0e1bda2669f398f865e6f81", null ],
    [ "source_urls", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a7f9a088e282e79d553130237084ab3e0", null ],
    [ "subtopics", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a4ffab41ec91be1244e3ed7eb94b40f3f", null ],
    [ "websocket", "classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#ac7fdf7619fee36a4feb5c8df6f712eb7", null ]
];