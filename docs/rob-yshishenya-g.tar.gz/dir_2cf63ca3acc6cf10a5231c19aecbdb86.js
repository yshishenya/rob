var dir_2cf63ca3acc6cf10a5231c19aecbdb86 =
[
    [ "__init__.py", "gpt__researcher_2retrievers_2serper_2____init_____8py.html", null ],
    [ "serper.py", "serper_8py.html", "serper_8py" ]
];