var namespacegpt__researcher_1_1llm__provider_1_1google =
[
    [ "google", "namespacegpt__researcher_1_1llm__provider_1_1google_1_1google.html", "namespacegpt__researcher_1_1llm__provider_1_1google_1_1google" ]
];