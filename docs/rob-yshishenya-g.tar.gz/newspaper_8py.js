var newspaper_8py =
[
    [ "gpt_researcher.scraper.newspaper.newspaper.NewspaperScraper", "classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper.html", "classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper" ]
];