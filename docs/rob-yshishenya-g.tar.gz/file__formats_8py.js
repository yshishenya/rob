var file__formats_8py =
[
    [ "write_md_to_pdf", "file__formats_8py.html#a381d88777ec5b123fc0c7f5b8357f96b", null ],
    [ "write_md_to_word", "file__formats_8py.html#a418dc3a64d94136480c6a27a8050cfee", null ],
    [ "write_text_to_md", "file__formats_8py.html#a291480dc71d67af0e177df6daefe0942", null ],
    [ "write_to_file", "file__formats_8py.html#ad0218eec891397e9e5fc972b4c9ce1b3", null ]
];