var websocket__manager_8py =
[
    [ "backend.websocket_manager.WebSocketManager", "classbackend_1_1websocket__manager_1_1WebSocketManager.html", "classbackend_1_1websocket__manager_1_1WebSocketManager" ],
    [ "run_agent", "websocket__manager_8py.html#ad5e0c8aa0f181850975a175494cab870", null ]
];