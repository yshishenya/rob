var enum_8py =
[
    [ "gpt_researcher.utils.enum.ReportType", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType" ],
    [ "gpt_researcher.utils.enum.ReportSource", "classgpt__researcher_1_1utils_1_1enum_1_1ReportSource.html", "classgpt__researcher_1_1utils_1_1enum_1_1ReportSource" ]
];