var searchData=
[
  ['database_5furl_0',['DATABASE_URL',['../namespacebackend_1_1db.html#a2712f6a35719e12a41eb5c87bffcea74',1,'backend.db.DATABASE_URL'],['../namespacedb__seed.html#a117e9500c3cfbce3c47a78dce5d3387a',1,'db_seed.DATABASE_URL']]],
  ['date_1',['date',['../classmemory_1_1research_1_1ResearchState.html#a295d210773dc95caea1e0fe3bd458025',1,'memory::research::ResearchState']]],
  ['ddg_2',['ddg',['../classgpt__researcher_1_1retrievers_1_1duckduckgo_1_1duckduckgo_1_1Duckduckgo.html#aab65e85d83c2adb5d8b3796f3dd421fb',1,'gpt_researcher::retrievers::duckduckgo::duckduckgo::Duckduckgo']]],
  ['default_5fdatabase_5furl_3',['DEFAULT_DATABASE_URL',['../namespacedb__seed.html#a3a13123e1feae6f94734cb4ce2458a4a',1,'db_seed']]],
  ['default_5fengine_4',['default_engine',['../namespacedb__seed.html#a52ec56261a6019cbf3d0a865706088e7',1,'db_seed']]],
  ['delete_5fuser_5fid_5',['delete_user_id',['../namespaceusers.html#a02db70f5ffcf3f872bc01e4506d3422d',1,'users']]],
  ['deployment_5fname_6',['deployment_name',['../classgpt__researcher_1_1llm__provider_1_1azureopenai_1_1azureopenai_1_1AzureOpenAIProvider.html#ad68ec6f87fb1cb6d6ad4291da0bf828d',1,'gpt_researcher::llm_provider::azureopenai::azureopenai::AzureOpenAIProvider']]],
  ['description_7',['description',['../namespacesetup.html#aedf461ec52a946bda975938ba0b93ec0',1,'setup']]],
  ['detailedreport_8',['DetailedReport',['../classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#af840c0b75b47688f7af4e19d525deffe',1,'gpt_researcher::utils::enum::ReportType']]],
  ['doc_5fpath_9',['doc_path',['../classgpt__researcher_1_1config_1_1config_1_1Config.html#a4d77682f7fb301859b810ce82ea77e38',1,'gpt_researcher::config::config::Config']]],
  ['documents_10',['documents',['../classgpt__researcher_1_1context_1_1compression_1_1ContextCompressor.html#a772447db72fc7fd103952671326ccb8e',1,'gpt_researcher::context::compression::ContextCompressor']]],
  ['draft_11',['draft',['../classmemory_1_1draft_1_1DraftState.html#a2ff087066da05f32a690858b7830b1cd',1,'memory::draft::DraftState']]]
];
