var searchData=
[
  ['add_5fcosts_0',['add_costs',['../classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher.html#a52fbcf367ccf81e1ba03858f60acc540',1,'gpt_researcher::master::agent::GPTResearcher']]],
  ['add_5fheader_1',['add_header',['../namespaceweb__scrape.html#a4ca49a63b7463a7b860ea919a026a80a',1,'web_scrape']]],
  ['add_5fsource_5furls_2',['add_source_urls',['../namespacegpt__researcher_1_1master_1_1actions.html#a630696213d37144e381817ac97f9f854',1,'gpt_researcher::master::actions']]],
  ['async_5fbrowse_3',['async_browse',['../namespaceweb__scrape.html#aae251defc7a9fb4c5b8085b5a75a7a35',1,'web_scrape']]],
  ['auto_5fagent_5finstructions_4',['auto_agent_instructions',['../namespacegpt__researcher_1_1master_1_1prompts.html#a1b8b6bf3d2fe1f56795cf36c745c9545',1,'gpt_researcher::master::prompts']]]
];
