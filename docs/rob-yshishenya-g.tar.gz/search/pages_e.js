var searchData=
[
  ['website_0',['Website',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2README.html',1,'']]],
  ['welcome_1',['Welcome',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2welcome.html',1,'']]]
];
