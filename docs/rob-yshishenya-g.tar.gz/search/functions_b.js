var searchData=
[
  ['on_5flogin_5fclicked_0',['on_login_clicked',['../namespaceusers.html#ae68a82800a1d784a4aa0d4e663382aad',1,'users']]],
  ['open_5ftask_1',['open_task',['../namespacemain.html#a595b471ed5c7eee2f4d04ae83edfe8c7',1,'main']]]
];
