var searchData=
[
  ['web_5fscrape_0',['web_scrape',['../namespaceweb__scrape.html',1,'']]]
];
