var searchData=
[
  ['📄_0',['Research on Local Documents 📄',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2tailored-research.html#autotoc_md138',1,'']]],
  ['📄_20research_20on_20local_20documents_1',['📄 Research on Local Documents',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2README.html#autotoc_md217',1,'']]]
];
