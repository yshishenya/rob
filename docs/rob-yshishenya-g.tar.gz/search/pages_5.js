var searchData=
[
  ['getting_20started_0',['Getting Started',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2getting-started.html',1,'']]],
  ['gpt_20researcher_1',['GPT Researcher',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2gpt__researcher_2README.html',1,'🔎 GPT Researcher'],['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2README-zh__CN.html',1,'🔎 GPT Researcher'],['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2multi__agents_2README.html',1,'LangGraph x GPT Researcher']]]
];
