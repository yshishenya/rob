var searchData=
[
  ['📋_0',['Example 2: Resource Report 📋',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2pip-package.html#autotoc_md129',1,'']]]
];
