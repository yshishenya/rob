var searchData=
[
  ['👪_20multi_20agent_20assistant_0',['👪 Multi-Agent Assistant',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2README.html#autotoc_md219',1,'']]]
];
