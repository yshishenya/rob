var searchData=
[
  ['delete_5fall_5frefresh_5ftokens_5fby_5fuser_5fid_0',['delete_all_refresh_tokens_by_user_id',['../classredis__token__storage_1_1RedisTokenStorage.html#ae8dd99f867d56a7d22cc51abe948835c',1,'redis_token_storage::RedisTokenStorage']]],
  ['delete_5frefresh_5ftoken_1',['delete_refresh_token',['../classredis__token__storage_1_1RedisTokenStorage.html#ad4043839e9087a9580f0cdb73e61ec0b',1,'redis_token_storage::RedisTokenStorage']]],
  ['delete_5ftoken_2',['delete_token',['../classredis__token__storage_1_1RedisTokenStorage.html#aaefb2d86c8ecfcfc7b4d6fc668b0142f',1,'redis_token_storage.RedisTokenStorage.delete_token()'],['../classtoken__storage_1_1TokenStorage.html#a0993266db9e1a278fb77d46fc2ab9fed',1,'token_storage.TokenStorage.delete_token()']]],
  ['delete_5ftokens_5fby_5fuser_5fid_3',['delete_tokens_by_user_id',['../classredis__token__storage_1_1RedisTokenStorage.html#a025c443b1f988143a8f3624a2457a08b',1,'redis_token_storage::RedisTokenStorage']]],
  ['delete_5fuser_4',['delete_user',['../namespaceauth.html#a1255c2b2d79877783d9ac9c59b9cba0f',1,'auth.delete_user()'],['../namespaceusers.html#abe93ce193b17b4e895eab26ae2806aaa',1,'users.delete_user()']]],
  ['disconnect_5',['disconnect',['../classbackend_1_1websocket__manager_1_1WebSocketManager.html#a2e59a99e26eae2043d78dc1bbd6cb3b7',1,'backend::websocket_manager::WebSocketManager']]],
  ['display_5fusers_6',['display_users',['../namespaceusers.html#a22767a039fbf019d609ba4ae7ee70199',1,'users']]]
];
