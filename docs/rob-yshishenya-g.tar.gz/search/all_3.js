var searchData=
[
  ['3_20temporary_20ban_0',['3. Temporary Ban',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2CODE__OF__CONDUCT.html#autotoc_md47',1,'']]],
  ['3_3a_20outline_20report_20📝_1',['Example 3: Outline Report 📝',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2pip-package.html#autotoc_md130',1,'']]]
];
