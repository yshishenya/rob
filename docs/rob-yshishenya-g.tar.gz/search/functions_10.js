var searchData=
[
  ['validate_5fdoc_5fpath_0',['validate_doc_path',['../classgpt__researcher_1_1config_1_1config_1_1Config.html#a5225566b494e714c3eb4289a2eb2c1ca',1,'gpt_researcher::config::config::Config']]]
];
