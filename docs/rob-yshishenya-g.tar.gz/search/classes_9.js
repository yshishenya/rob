var searchData=
[
  ['newspaperscraper_0',['NewspaperScraper',['../classgpt__researcher_1_1scraper_1_1newspaper_1_1newspaper_1_1NewspaperScraper.html',1,'gpt_researcher::scraper::newspaper::newspaper']]]
];
