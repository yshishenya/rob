var searchData=
[
  ['global_5fcontext_0',['global_context',['../classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a2655bf073543019eefe8c1ae96168f73',1,'backend::report_type::detailed_report::detailed_report::DetailedReport']]],
  ['global_5furls_1',['global_urls',['../classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#ad751ada9bed4490bb6dff1157ac6885c',1,'backend::report_type::detailed_report::detailed_report::DetailedReport']]],
  ['graph_2',['graph',['../namespaceagent.html#a506a8909f4cc88c2c31135a29dadbddb',1,'agent']]]
];
