var searchData=
[
  ['cfg_0',['cfg',['../classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher.html#aff6f2c41bd6081bcd4ebdd4be6bcba7b',1,'gpt_researcher::master::agent::GPTResearcher']]],
  ['chief_5feditor_1',['chief_editor',['../namespaceagent.html#a95435a4e96e81f83e8c22bbf23d72864',1,'agent']]],
  ['choices_2',['choices',['../namespacecli.html#a65f014f9d134c9c500c920de65e2ad02',1,'cli']]],
  ['classifiers_3',['classifiers',['../namespacesetup.html#abe96a9c38c1c61f9f0fdb002c482f785',1,'setup']]],
  ['cli_4',['cli',['../namespacecli.html#acaca8ac2bee7e16ecd95cc31d0bb9c64',1,'cli']]],
  ['client_5',['client',['../classgpt__researcher_1_1retrievers_1_1google_1_1google_1_1GoogleSearch.html#a3f4be81fe04dbaf65b7958ceafc19054',1,'gpt_researcher.retrievers.google.google.GoogleSearch.client'],['../classgpt__researcher_1_1retrievers_1_1searx_1_1searx_1_1SearxSearch.html#a6181b9b1d2cca03751489821ea8bfd9b',1,'gpt_researcher.retrievers.searx.searx.SearxSearch.client'],['../classgpt__researcher_1_1retrievers_1_1tavily_1_1tavily__search_1_1TavilySearch.html#a245d61c57d930d3e8573387ef0c9d52c',1,'gpt_researcher.retrievers.tavily.tavily_search.TavilySearch.client']]],
  ['conclusion_6',['conclusion',['../classmemory_1_1research_1_1ResearchState.html#aed34aa52f6a45b13953be9d50bc8c6c4',1,'memory::research::ResearchState']]],
  ['config_5ffile_7',['config_file',['../classgpt__researcher_1_1config_1_1config_1_1Config.html#a619e730ee1d3e79c9a5ef83705960b44',1,'gpt_researcher::config::config::Config']]],
  ['config_5fpath_8',['config_path',['../classbackend_1_1report__type_1_1basic__report_1_1basic__report_1_1BasicReport.html#af52dae954af0dd59a2b4c714f0616ef0',1,'backend.report_type.basic_report.basic_report.BasicReport.config_path'],['../classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#a221962d4df23d2476a24fcda876d037a',1,'backend.report_type.detailed_report.detailed_report.DetailedReport.config_path']]],
  ['context_9',['context',['../classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher.html#af5c3a3e200d4cb2522e132a20be4d228',1,'gpt_researcher::master::agent::GPTResearcher']]],
  ['customreport_10',['CustomReport',['../classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#a504d1981defb724d1b01a57c6c9bebb6',1,'gpt_researcher::utils::enum::ReportType']]],
  ['cx_5fkey_11',['cx_key',['../classgpt__researcher_1_1retrievers_1_1google_1_1google_1_1GoogleSearch.html#a092ef162fe4943eca7da1d402a73bce9',1,'gpt_researcher::retrievers::google::google::GoogleSearch']]]
];
