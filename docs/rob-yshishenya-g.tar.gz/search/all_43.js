var searchData=
[
  ['📚_0',['📚',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2pip-package.html#autotoc_md128',1,'Example 1: Research Report 📚'],['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2tailored-research.html#autotoc_md136',1,'Research on Specific Sources 📚']]]
];
