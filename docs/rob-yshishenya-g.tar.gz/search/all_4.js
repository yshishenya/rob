var searchData=
[
  ['4_20does_20not_20exist_0',['model: gpt-4 does not exist',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2troubleshooting.html#autotoc_md140',1,'']]],
  ['4_20permanent_20ban_1',['4. Permanent Ban',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2CODE__OF__CONDUCT.html#autotoc_md48',1,'']]]
];
