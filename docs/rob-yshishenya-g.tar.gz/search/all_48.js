var searchData=
[
  ['🛡_20免责声明_0',['🛡 免责声明',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2README-zh__CN.html#autotoc_md204',1,'']]],
  ['🛡_20disclaimer_1',['🛡 Disclaimer',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2README.html#autotoc_md222',1,'']]]
];
