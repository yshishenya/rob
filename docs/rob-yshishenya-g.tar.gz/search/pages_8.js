var searchData=
[
  ['of_20conduct_0',['Contributor Covenant Code of Conduct',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2CODE__OF__CONDUCT.html',1,'']]]
];
