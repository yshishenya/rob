var searchData=
[
  ['index_2emd_0',['index.md',['../2023-09-22-gpt-researcher_2index_8md.html',1,'(Global Namespace)'],['../2023-11-12-openai-assistant_2index_8md.html',1,'(Global Namespace)'],['../2024-05-19-gptr-langgraph_2index_8md.html',1,'(Global Namespace)']]],
  ['introduction_2emd_1',['introduction.md',['../introduction_8md.html',1,'']]]
];
