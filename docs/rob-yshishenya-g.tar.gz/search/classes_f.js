var searchData=
[
  ['user_0',['User',['../classbackend_1_1db_1_1User.html',1,'backend.db.User'],['../classdb__seed_1_1User.html',1,'db_seed.User']]],
  ['usercreaterequest_1',['UserCreateRequest',['../classauth_1_1UserCreateRequest.html',1,'auth']]],
  ['userresponse_2',['UserResponse',['../classauth_1_1UserResponse.html',1,'auth']]]
];
