var searchData=
[
  ['ollama_2epy_0',['ollama.py',['../ollama_8py.html',1,'']]],
  ['openai_2epy_1',['openai.py',['../openai_8py.html',1,'']]]
];
