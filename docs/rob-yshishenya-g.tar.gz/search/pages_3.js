var searchData=
[
  ['example_0',['Agent Example',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2example.html',1,'']]],
  ['examples_1',['Examples',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2examples_2examples.html',1,'']]]
];
