var searchData=
[
  ['newspaper_2epy_0',['newspaper.py',['../newspaper_8py.html',1,'']]]
];
