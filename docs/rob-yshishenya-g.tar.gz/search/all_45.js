var searchData=
[
  ['🔎_20gpt_20researcher_0',['🔎 GPT Researcher',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2gpt__researcher_2README.html',1,'🔎 GPT Researcher'],['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2README-zh__CN.html',1,'🔎 GPT Researcher']]]
];
