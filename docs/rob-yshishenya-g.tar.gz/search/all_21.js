var searchData=
[
  ['введение_0',['Введение',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md2',1,'']]]
];
