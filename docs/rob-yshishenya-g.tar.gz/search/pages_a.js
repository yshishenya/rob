var searchData=
[
  ['questions_0',['Frequently Asked Questions',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2faq.html',1,'']]]
];
