var searchData=
[
  ['detailed_20reports_0',['Detailed Reports',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2report__type_2detailed__report_2README.html',1,'']]]
];
