var searchData=
[
  ['⚙️_20getting_20started_0',['⚙️ Getting Started',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2README.html#autotoc_md213',1,'']]]
];
