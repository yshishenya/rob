var searchData=
[
  ['к_20websocket_0',['Пример подключения к WebSocket',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md10',1,'']]]
];
