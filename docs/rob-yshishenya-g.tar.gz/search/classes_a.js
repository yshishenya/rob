var searchData=
[
  ['ollamaprovider_0',['OllamaProvider',['../classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html',1,'gpt_researcher::llm_provider::ollama::ollama']]],
  ['openaiprovider_1',['OpenAIProvider',['../classgpt__researcher_1_1llm__provider_1_1openai_1_1openai_1_1OpenAIProvider.html',1,'gpt_researcher::llm_provider::openai::openai']]]
];
