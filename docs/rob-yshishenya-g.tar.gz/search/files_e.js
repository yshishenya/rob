var searchData=
[
  ['pip_2dpackage_2emd_0',['pip-package.md',['../pip-package_8md.html',1,'']]],
  ['prompts_2epy_1',['prompts.py',['../prompts_8py.html',1,'']]],
  ['publisher_2epy_2',['publisher.py',['../publisher_8py.html',1,'']]],
  ['pymupdf_2epy_3',['pymupdf.py',['../pymupdf_8py.html',1,'']]]
];
