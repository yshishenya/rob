var searchData=
[
  ['main_0',['main',['../namespacemain.html',1,'']]],
  ['memory_1',['memory',['../namespacememory.html',1,'']]],
  ['memory_3a_3adraft_2',['draft',['../namespacememory_1_1draft.html',1,'memory']]],
  ['memory_3a_3aresearch_3',['research',['../namespacememory_1_1research.html',1,'memory']]]
];
