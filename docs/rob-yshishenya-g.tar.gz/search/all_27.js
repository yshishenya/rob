var searchData=
[
  ['маршруты_0',['API Маршруты',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md23',1,'']]],
  ['модели_20pydantic_1',['Модели Pydantic',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md21',1,'']]],
  ['модуль_20auth_20py_2',['Модуль auth.py',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md20',1,'']]],
  ['модуль_20server_20py_3',['Модуль server.py',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md33',1,'']]]
];
