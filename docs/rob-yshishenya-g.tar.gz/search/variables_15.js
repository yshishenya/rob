var searchData=
[
  ['verbose_0',['verbose',['../classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher.html#a1123a9ceccf591cd94ec5fe17e429767',1,'gpt_researcher::master::agent::GPTResearcher']]],
  ['version_1',['version',['../namespacesetup.html#a2aa722b36a933088812b50ea79b97a5c',1,'setup']]],
  ['visited_5furls_2',['visited_urls',['../classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher.html#af5a1522c96e7986b69b493095f9d0e53',1,'gpt_researcher::master::agent::GPTResearcher']]]
];
