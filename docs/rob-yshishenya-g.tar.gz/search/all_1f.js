var searchData=
[
  ['you_20ensure_20the_20report_20is_20factual_20and_20accurate_0',['How do you ensure the report is factual and accurate?',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2faq.html#autotoc_md78',1,'']]],
  ['your_20plans_20for_20the_20future_1',['What are your plans for the future?',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2faq.html#autotoc_md79',1,'']]]
];
