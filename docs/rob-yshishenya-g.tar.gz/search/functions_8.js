var searchData=
[
  ['init_5fapp_0',['init_app',['../namespaceauth.html#a0576ac38388513ffb14572026ff67e2a',1,'auth']]],
  ['init_5fdb_1',['init_db',['../namespacebackend_1_1db.html#aede5ea7cecfbb5e666435bbf5fad8735',1,'backend::db']]],
  ['init_5fresearch_5fteam_2',['init_research_team',['../classagents_1_1master_1_1ChiefEditorAgent.html#a208d36c007aa6f97cb6e13ed39cd2623',1,'agents::master::ChiefEditorAgent']]]
];
