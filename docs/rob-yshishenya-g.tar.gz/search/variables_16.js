var searchData=
[
  ['web_0',['Web',['../classgpt__researcher_1_1utils_1_1enum_1_1ReportSource.html#a6da128c50580df465b9e34330783ce34',1,'gpt_researcher::utils::enum::ReportSource']]],
  ['websocket_1',['websocket',['../classbackend_1_1report__type_1_1basic__report_1_1basic__report_1_1BasicReport.html#a1d61521e8a9cc6dd46ce7dd2cabe97c1',1,'backend.report_type.basic_report.basic_report.BasicReport.websocket'],['../classbackend_1_1report__type_1_1detailed__report_1_1detailed__report_1_1DetailedReport.html#ac7fdf7619fee36a4feb5c8df6f712eb7',1,'backend.report_type.detailed_report.detailed_report.DetailedReport.websocket'],['../classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher.html#a24933598e47970d88a094e8ef12cb61d',1,'gpt_researcher.master.agent.GPTResearcher.websocket']]],
  ['writer_2',['WRITER',['../classagents_1_1utils_1_1views_1_1AgentColor.html#a55c936b52836cd867677166ed7d0390b',1,'agents::utils::views::AgentColor']]]
];
