var searchData=
[
  ['web_5fbase_5floader_2epy_0',['web_base_loader.py',['../web__base__loader_8py.html',1,'']]],
  ['web_5fscrape_2epy_1',['web_scrape.py',['../web__scrape_8py.html',1,'']]],
  ['websocket_5fmanager_2epy_2',['websocket_manager.py',['../websocket__manager_8py.html',1,'']]],
  ['welcome_2emd_3',['welcome.md',['../welcome_8md.html',1,'']]],
  ['writer_2epy_4',['writer.py',['../writer_8py.html',1,'']]]
];
