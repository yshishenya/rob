var searchData=
[
  ['📝_0',['📝',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2pip-package.html#autotoc_md130',1,'Example 3: Outline Report 📝'],['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2pip-package.html#autotoc_md126',1,'Example Usage 📝'],['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2tailored-research.html#autotoc_md137',1,'Specify Agent Prompt 📝']]]
];
