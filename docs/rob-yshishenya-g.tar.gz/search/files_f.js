var searchData=
[
  ['readme_2dzh_5fcn_2emd_0',['README-zh_CN.md',['../README-zh__CN_8md.html',1,'']]],
  ['readme_2emd_1',['README.md',['../backend_2report__type_2detailed__report_2README_8md.html',1,'(Global Namespace)'],['../docs_2README_8md.html',1,'(Global Namespace)'],['../gpt__researcher_2README_8md.html',1,'(Global Namespace)'],['../multi__agents_2README_8md.html',1,'(Global Namespace)'],['../README_8md.html',1,'(Global Namespace)']]],
  ['redis_5ftoken_5fstorage_2epy_2',['redis_token_storage.py',['../redis__token__storage_8py.html',1,'']]],
  ['research_2epy_3',['research.py',['../research_8py.html',1,'']]],
  ['researcher_2epy_4',['researcher.py',['../researcher_8py.html',1,'']]],
  ['retriever_2epy_5',['retriever.py',['../retriever_8py.html',1,'']]],
  ['reviewer_2epy_6',['reviewer.py',['../reviewer_8py.html',1,'']]],
  ['reviser_2epy_7',['reviser.py',['../reviser_8py.html',1,'']]],
  ['roadmap_2emd_8',['roadmap.md',['../roadmap_8md.html',1,'']]]
];
