var searchData=
[
  ['json_20contains_20the_20following_20fields_3a_0',['Json contains the following fields:',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2langgraph.html#autotoc_md107',1,'Task.json contains the following fields:'],['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2multi__agents_2README.html#autotoc_md191',1,'Task.json contains the following fields:']]]
];
