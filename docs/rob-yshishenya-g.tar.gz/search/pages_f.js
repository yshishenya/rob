var searchData=
[
  ['x_20gpt_20researcher_0',['LangGraph x GPT Researcher',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2multi__agents_2README.html',1,'']]]
];
