var searchData=
[
  ['loginrequest_0',['LoginRequest',['../classauth_1_1LoginRequest.html',1,'auth']]],
  ['loginresponse_1',['LoginResponse',['../classauth_1_1LoginResponse.html',1,'auth']]]
];
