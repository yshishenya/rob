var searchData=
[
  ['работы_20с_20токенами_0',['Функции для работы с токенами',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md22',1,'']]],
  ['реализации_20логаута_1',['Инструкция по реализации логаута',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md34',1,'']]],
  ['руководство_20по_20использованию_20api_2',['Руководство по использованию API',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2backend_2auth_2auth.html#autotoc_md1',1,'']]]
];
