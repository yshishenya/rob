var searchData=
[
  ['hugginfaceprovider_0',['HugginFaceProvider',['../classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html',1,'gpt_researcher::llm_provider::huggingface::huggingface']]]
];
