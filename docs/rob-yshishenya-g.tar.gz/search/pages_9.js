var searchData=
[
  ['package_0',['PIP Package',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2pip-package.html',1,'']]],
  ['pip_20package_1',['PIP Package',['../md__2tmp_2github__repos__arch__doc__gen_2yshishenya_2rob_2docs_2docs_2gpt-researcher_2pip-package.html',1,'']]]
];
