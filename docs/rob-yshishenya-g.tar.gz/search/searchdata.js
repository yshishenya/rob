var indexSectionsWithContent =
{
  0: "012347_abcdefghijklmnopqrstuvwxyавдзиклмнопрстуф⚙✉为免快支教文架演特联贡🌍🌐👪📄📋📖📚📝🔎🚀🛠🛡",
  1: "abcdeghlmnoprstuw",
  2: "abcdgmprstuw",
  3: "_abcdefghilmnoprstuvw",
  4: "_abcdefgilmoprstvw",
  5: "_abcdefghiklmnopqrstuvw",
  6: "acdefgilopqrstwx🔎"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

