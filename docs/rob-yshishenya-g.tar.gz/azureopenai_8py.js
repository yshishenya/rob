var azureopenai_8py =
[
    [ "gpt_researcher.llm_provider.azureopenai.azureopenai.AzureOpenAIProvider", "classgpt__researcher_1_1llm__provider_1_1azureopenai_1_1azureopenai_1_1AzureOpenAIProvider.html", "classgpt__researcher_1_1llm__provider_1_1azureopenai_1_1azureopenai_1_1AzureOpenAIProvider" ]
];