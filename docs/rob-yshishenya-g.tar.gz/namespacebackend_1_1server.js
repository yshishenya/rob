var namespacebackend_1_1server =
[
    [ "ResearchRequest", "classbackend_1_1server_1_1ResearchRequest.html", "classbackend_1_1server_1_1ResearchRequest" ],
    [ "format_filename", "namespacebackend_1_1server.html#a9c30cd96e9e80accf2505265058bb685", null ],
    [ "read_root", "namespacebackend_1_1server.html#aaf74caa59bfb354fc9376ff64b5b0450", null ],
    [ "save_request_to_file", "namespacebackend_1_1server.html#ad4dad2e900f405ce89832734ae7a4b80", null ],
    [ "startup_event", "namespacebackend_1_1server.html#aa20a85ade2f14a7b9746f098733052a9", null ],
    [ "websocket_endpoint", "namespacebackend_1_1server.html#add4a342eaeb04b916c8e3ca8ee280129", null ],
    [ "allow_credentials", "namespacebackend_1_1server.html#a02a6dbac09a1e44d53dac146b4b7995e", null ],
    [ "allow_headers", "namespacebackend_1_1server.html#ac0adc8d19eae0c9e8eaa11d97e60657b", null ],
    [ "allow_methods", "namespacebackend_1_1server.html#a31453585c4b681dd455b119aad8df27f", null ],
    [ "allow_origins", "namespacebackend_1_1server.html#afd315579b9669e0ddf3c7380195c2c9f", null ],
    [ "app", "namespacebackend_1_1server.html#a7b499ff940ba3d60a6a446047dc0e793", null ],
    [ "level", "namespacebackend_1_1server.html#a791304efa6d9abc2d7224777155f4ce3", null ],
    [ "logger", "namespacebackend_1_1server.html#ac7ba92e1518c9942f9b2628e59284036", null ],
    [ "manager", "namespacebackend_1_1server.html#a967b877415aecb102a7fc379ce5041b1", null ],
    [ "name", "namespacebackend_1_1server.html#a3fb990b8f65eceb426d3046cca41f3be", null ],
    [ "templates", "namespacebackend_1_1server.html#a08ea44cc61f6d390978edd06e68867b2", null ]
];