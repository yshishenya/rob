var namespacegpt__researcher_1_1scraper_1_1pymupdf =
[
    [ "pymupdf", "namespacegpt__researcher_1_1scraper_1_1pymupdf_1_1pymupdf.html", "namespacegpt__researcher_1_1scraper_1_1pymupdf_1_1pymupdf" ]
];