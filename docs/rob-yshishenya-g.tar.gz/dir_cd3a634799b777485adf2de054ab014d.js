var dir_cd3a634799b777485adf2de054ab014d =
[
    [ "__init__.py", "gpt__researcher_2llm__provider_2ollama_2____init_____8py.html", null ],
    [ "ollama.py", "ollama_8py.html", "ollama_8py" ]
];