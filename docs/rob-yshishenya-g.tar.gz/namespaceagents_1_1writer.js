var namespaceagents_1_1writer =
[
    [ "WriterAgent", "classagents_1_1writer_1_1WriterAgent.html", "classagents_1_1writer_1_1WriterAgent" ],
    [ "sample_json", "namespaceagents_1_1writer.html#a4c5d07e2e9e57563dbcb39ba7feddab6", null ]
];