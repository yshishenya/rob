var reviser_8py =
[
    [ "agents.reviser.ReviserAgent", "classagents_1_1reviser_1_1ReviserAgent.html", "classagents_1_1reviser_1_1ReviserAgent" ],
    [ "sample_revision_notes", "reviser_8py.html#adced1481093055f3bbb05ed5c543d1c4", null ]
];