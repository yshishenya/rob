var namespacegpt__researcher_1_1master =
[
    [ "actions", "namespacegpt__researcher_1_1master_1_1actions.html", [
      [ "add_source_urls", "namespacegpt__researcher_1_1master_1_1actions.html#a630696213d37144e381817ac97f9f854", null ],
      [ "choose_agent", "namespacegpt__researcher_1_1master_1_1actions.html#a5d28ace9f81401032833fb86c2707d98", null ],
      [ "extract_headers", "namespacegpt__researcher_1_1master_1_1actions.html#a68c6082998cf41e463530cb9f128c8be", null ],
      [ "generate_report", "namespacegpt__researcher_1_1master_1_1actions.html#a9c7b3c1544156eb008fadfb06a415c20", null ],
      [ "get_report_introduction", "namespacegpt__researcher_1_1master_1_1actions.html#aa1ac642119ea75be5ce8a9f6ad913550", null ],
      [ "get_retriever", "namespacegpt__researcher_1_1master_1_1actions.html#acfce0fe9e02f7246bcace8600279263f", null ],
      [ "get_sub_queries", "namespacegpt__researcher_1_1master_1_1actions.html#a5ec2fcb09935e7c20c484b43edd24cd6", null ],
      [ "scrape_urls", "namespacegpt__researcher_1_1master_1_1actions.html#a6df8ff25a470a78ca849b1b12bd7e043", null ],
      [ "stream_output", "namespacegpt__researcher_1_1master_1_1actions.html#abe8547773bf18846d57805ac145cf03e", null ],
      [ "summarize", "namespacegpt__researcher_1_1master_1_1actions.html#a28ac426e24fade0611138b18e12b07d0", null ],
      [ "summarize_url", "namespacegpt__researcher_1_1master_1_1actions.html#ac98e8d537910db157298a4f600214549", null ],
      [ "table_of_contents", "namespacegpt__researcher_1_1master_1_1actions.html#a5ae5fa76d436f86a64149fe871e32515", null ]
    ] ],
    [ "agent", "namespacegpt__researcher_1_1master_1_1agent.html", "namespacegpt__researcher_1_1master_1_1agent" ],
    [ "prompts", "namespacegpt__researcher_1_1master_1_1prompts.html", [
      [ "auto_agent_instructions", "namespacegpt__researcher_1_1master_1_1prompts.html#a1b8b6bf3d2fe1f56795cf36c745c9545", null ],
      [ "generate_custom_report_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#a32d1e3b87f76b16c6934959abc348ec0", null ],
      [ "generate_outline_report_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#a250d14916f8487c0a0a5959322e51b10", null ],
      [ "generate_report_introduction", "namespacegpt__researcher_1_1master_1_1prompts.html#a5ab2bf457ff727dc200a27395b0b05c8", null ],
      [ "generate_report_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#aa1acdb319226c2434745dd28ddc12a13", null ],
      [ "generate_resource_report_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#a076ce149c880d13d4702ff92da83d7f5", null ],
      [ "generate_search_queries_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#a1515d26ed2febbb7bb2670723e9bc3c7", null ],
      [ "generate_subtopic_report_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#afe484ac6f9c1a55a54a9b2add561ff4d", null ],
      [ "generate_subtopics_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#afa1a6e6fa275aa54ca3cf6f5030d5f8e", null ],
      [ "generate_summary_prompt", "namespacegpt__researcher_1_1master_1_1prompts.html#aa624fb10f7c23dd338e53222a0de584c", null ],
      [ "get_prompt_by_report_type", "namespacegpt__researcher_1_1master_1_1prompts.html#abb901630f113e1efe4c635c5f6e8229c", null ],
      [ "get_report_by_type", "namespacegpt__researcher_1_1master_1_1prompts.html#ab0519037b4c15adb99ff3dd89076c9e9", null ],
      [ "report_type_mapping", "namespacegpt__researcher_1_1master_1_1prompts.html#aaffdcbce2b4c96cc4fc6f8bb4411bc23", null ]
    ] ],
    [ "__all__", "namespacegpt__researcher_1_1master.html#aea6802ff29921a1c35e9f49531f99b81", null ]
];