var dir_93c3e6444ead30d4602574fa7e788534 =
[
    [ "__init__.py", "gpt__researcher_2scraper_2beautiful__soup_2____init_____8py.html", null ],
    [ "beautiful_soup.py", "beautiful__soup_8py.html", "beautiful__soup_8py" ]
];