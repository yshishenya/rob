var openai_8py =
[
    [ "gpt_researcher.llm_provider.openai.openai.OpenAIProvider", "classgpt__researcher_1_1llm__provider_1_1openai_1_1openai_1_1OpenAIProvider.html", "classgpt__researcher_1_1llm__provider_1_1openai_1_1openai_1_1OpenAIProvider" ]
];