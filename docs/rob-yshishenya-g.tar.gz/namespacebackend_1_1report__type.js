var namespacebackend_1_1report__type =
[
    [ "basic_report", "namespacebackend_1_1report__type_1_1basic__report.html", "namespacebackend_1_1report__type_1_1basic__report" ],
    [ "detailed_report", "namespacebackend_1_1report__type_1_1detailed__report.html", "namespacebackend_1_1report__type_1_1detailed__report" ],
    [ "__all__", "namespacebackend_1_1report__type.html#a926bda12b1e020f96b84d304394bdd9f", null ]
];