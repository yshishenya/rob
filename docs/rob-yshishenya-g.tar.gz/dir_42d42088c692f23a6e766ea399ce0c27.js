var dir_42d42088c692f23a6e766ea399ce0c27 =
[
    [ "auth", "dir_a9499db4338a32c38b4cdeeb0d839d88.html", "dir_a9499db4338a32c38b4cdeeb0d839d88" ],
    [ "report_type", "dir_aab170fbc980b9f46c5ef36e78faa03a.html", "dir_aab170fbc980b9f46c5ef36e78faa03a" ],
    [ "__init__.py", "backend_2____init_____8py.html", null ],
    [ "db.py", "db_8py.html", "db_8py" ],
    [ "server.py", "server_8py.html", "server_8py" ],
    [ "utils.py", "utils_8py.html", "utils_8py" ],
    [ "websocket_manager.py", "websocket__manager_8py.html", "websocket__manager_8py" ]
];