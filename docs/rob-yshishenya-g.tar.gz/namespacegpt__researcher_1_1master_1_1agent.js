var namespacegpt__researcher_1_1master_1_1agent =
[
    [ "GPTResearcher", "classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher.html", "classgpt__researcher_1_1master_1_1agent_1_1GPTResearcher" ]
];