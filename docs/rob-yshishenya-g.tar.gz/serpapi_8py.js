var serpapi_8py =
[
    [ "gpt_researcher.retrievers.serpapi.serpapi.SerpApiSearch", "classgpt__researcher_1_1retrievers_1_1serpapi_1_1serpapi_1_1SerpApiSearch.html", "classgpt__researcher_1_1retrievers_1_1serpapi_1_1serpapi_1_1SerpApiSearch" ]
];