var classmemory_1_1draft_1_1DraftState =
[
    [ "draft", "classmemory_1_1draft_1_1DraftState.html#a2ff087066da05f32a690858b7830b1cd", null ],
    [ "review", "classmemory_1_1draft_1_1DraftState.html#a98d9f0c97a9068937de25af7fd8400c8", null ],
    [ "revision_notes", "classmemory_1_1draft_1_1DraftState.html#a84634ee06bf0565241efaff29efa71db", null ],
    [ "task", "classmemory_1_1draft_1_1DraftState.html#a250fbcc1aa37c36a6c5be184d3957048", null ],
    [ "topic", "classmemory_1_1draft_1_1DraftState.html#a7a1419f6463612981b61bfd42e08e1e4", null ]
];