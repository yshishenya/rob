var classauth_1_1LoginRequest =
[
    [ "password", "classauth_1_1LoginRequest.html#a00b163d66ed8d5c77407465fa62b1a44", null ],
    [ "username", "classauth_1_1LoginRequest.html#a0e3f75a027dc97388ccfe3d12331a11b", null ]
];