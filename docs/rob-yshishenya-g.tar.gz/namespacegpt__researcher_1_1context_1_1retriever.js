var namespacegpt__researcher_1_1context_1_1retriever =
[
    [ "SearchAPIRetriever", "classgpt__researcher_1_1context_1_1retriever_1_1SearchAPIRetriever.html", "classgpt__researcher_1_1context_1_1retriever_1_1SearchAPIRetriever" ]
];