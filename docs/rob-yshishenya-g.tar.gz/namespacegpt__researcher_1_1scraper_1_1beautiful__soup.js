var namespacegpt__researcher_1_1scraper_1_1beautiful__soup =
[
    [ "beautiful_soup", "namespacegpt__researcher_1_1scraper_1_1beautiful__soup_1_1beautiful__soup.html", "namespacegpt__researcher_1_1scraper_1_1beautiful__soup_1_1beautiful__soup" ]
];