var namespacegpt__researcher_1_1scraper =
[
    [ "arxiv", "namespacegpt__researcher_1_1scraper_1_1arxiv.html", "namespacegpt__researcher_1_1scraper_1_1arxiv" ],
    [ "beautiful_soup", "namespacegpt__researcher_1_1scraper_1_1beautiful__soup.html", "namespacegpt__researcher_1_1scraper_1_1beautiful__soup" ],
    [ "newspaper", "namespacegpt__researcher_1_1scraper_1_1newspaper.html", "namespacegpt__researcher_1_1scraper_1_1newspaper" ],
    [ "pymupdf", "namespacegpt__researcher_1_1scraper_1_1pymupdf.html", "namespacegpt__researcher_1_1scraper_1_1pymupdf" ],
    [ "scraper", "namespacegpt__researcher_1_1scraper_1_1scraper.html", "namespacegpt__researcher_1_1scraper_1_1scraper" ],
    [ "web_base_loader", "namespacegpt__researcher_1_1scraper_1_1web__base__loader.html", "namespacegpt__researcher_1_1scraper_1_1web__base__loader" ],
    [ "__all__", "namespacegpt__researcher_1_1scraper.html#ae65e984827c791518c9f3ba5b725d82b", null ]
];