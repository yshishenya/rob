var namespacegpt__researcher_1_1llm__provider =
[
    [ "anthropic", "namespacegpt__researcher_1_1llm__provider_1_1anthropic.html", "namespacegpt__researcher_1_1llm__provider_1_1anthropic" ],
    [ "azureopenai", "namespacegpt__researcher_1_1llm__provider_1_1azureopenai.html", "namespacegpt__researcher_1_1llm__provider_1_1azureopenai" ],
    [ "generic", "namespacegpt__researcher_1_1llm__provider_1_1generic.html", "namespacegpt__researcher_1_1llm__provider_1_1generic" ],
    [ "google", "namespacegpt__researcher_1_1llm__provider_1_1google.html", "namespacegpt__researcher_1_1llm__provider_1_1google" ],
    [ "groq", "namespacegpt__researcher_1_1llm__provider_1_1groq.html", "namespacegpt__researcher_1_1llm__provider_1_1groq" ],
    [ "huggingface", "namespacegpt__researcher_1_1llm__provider_1_1huggingface.html", "namespacegpt__researcher_1_1llm__provider_1_1huggingface" ],
    [ "mistral", "namespacegpt__researcher_1_1llm__provider_1_1mistral.html", "namespacegpt__researcher_1_1llm__provider_1_1mistral" ],
    [ "ollama", "namespacegpt__researcher_1_1llm__provider_1_1ollama.html", "namespacegpt__researcher_1_1llm__provider_1_1ollama" ],
    [ "openai", "namespacegpt__researcher_1_1llm__provider_1_1openai.html", "namespacegpt__researcher_1_1llm__provider_1_1openai" ],
    [ "together", "namespacegpt__researcher_1_1llm__provider_1_1together.html", "namespacegpt__researcher_1_1llm__provider_1_1together" ],
    [ "__all__", "namespacegpt__researcher_1_1llm__provider.html#a91d2bd5c55978c07f716bbbaa0896684", null ]
];