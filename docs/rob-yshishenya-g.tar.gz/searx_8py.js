var searx_8py =
[
    [ "gpt_researcher.retrievers.searx.searx.SearxSearch", "classgpt__researcher_1_1retrievers_1_1searx_1_1searx_1_1SearxSearch.html", "classgpt__researcher_1_1retrievers_1_1searx_1_1searx_1_1SearxSearch" ]
];