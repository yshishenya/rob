var classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider =
[
    [ "__init__", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#ab514806071b2a6dce4907a35c6df8274", null ],
    [ "get_api_key", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#a9a73260eaa0b5bf18c9b67a82b3f77b9", null ],
    [ "get_chat_response", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#a29c4557a7dba4a30faf237cf98374de0", null ],
    [ "get_llm_model", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#a13b615065860169c0406faa06d0ec627", null ],
    [ "stream_response", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#a1cea93e5495738cf31047865f4c50448", null ],
    [ "api_key", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#acac348196c0ba3de9c81e6e182d4a6fd", null ],
    [ "llm", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#a60ae17b7c8f1446988ded590efda9e4a", null ],
    [ "max_tokens", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#a2a1a7e7ca34c9a9dabd4f5e7bc466837", null ],
    [ "model", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#af1fb58293b0de0d5c8d74bcecf9e8aa6", null ],
    [ "temperature", "classgpt__researcher_1_1llm__provider_1_1huggingface_1_1huggingface_1_1HugginFaceProvider.html#a744e253ed67e07d2bb6dcf988ee61ff8", null ]
];