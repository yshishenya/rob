var classbackend_1_1server_1_1ResearchRequest =
[
    [ "agent", "classbackend_1_1server_1_1ResearchRequest.html#a312e8b781e186a3e99f6005a0b5c41ef", null ],
    [ "report_type", "classbackend_1_1server_1_1ResearchRequest.html#a19cdda16ce044d65cd3d4734ff4cb7a8", null ],
    [ "task", "classbackend_1_1server_1_1ResearchRequest.html#a67fa07b5bff295d8cf39866f3703e3cd", null ]
];