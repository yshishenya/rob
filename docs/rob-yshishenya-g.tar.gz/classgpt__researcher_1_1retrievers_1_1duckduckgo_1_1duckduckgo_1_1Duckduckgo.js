var classgpt__researcher_1_1retrievers_1_1duckduckgo_1_1duckduckgo_1_1Duckduckgo =
[
    [ "__init__", "classgpt__researcher_1_1retrievers_1_1duckduckgo_1_1duckduckgo_1_1Duckduckgo.html#a4f281e7f15a5b19b874aed6ebc6255c2", null ],
    [ "search", "classgpt__researcher_1_1retrievers_1_1duckduckgo_1_1duckduckgo_1_1Duckduckgo.html#ad0bb732b805ce6b818f85959539e0806", null ],
    [ "ddg", "classgpt__researcher_1_1retrievers_1_1duckduckgo_1_1duckduckgo_1_1Duckduckgo.html#aab65e85d83c2adb5d8b3796f3dd421fb", null ],
    [ "query", "classgpt__researcher_1_1retrievers_1_1duckduckgo_1_1duckduckgo_1_1Duckduckgo.html#adc8d2faf8e34e22a9332fbb1456bf607", null ]
];