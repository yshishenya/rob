var writer_8py =
[
    [ "agents.writer.WriterAgent", "classagents_1_1writer_1_1WriterAgent.html", "classagents_1_1writer_1_1WriterAgent" ],
    [ "sample_json", "writer_8py.html#a4c5d07e2e9e57563dbcb39ba7feddab6", null ]
];