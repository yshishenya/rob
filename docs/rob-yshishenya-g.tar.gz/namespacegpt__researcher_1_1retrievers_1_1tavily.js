var namespacegpt__researcher_1_1retrievers_1_1tavily =
[
    [ "tavily_search", "namespacegpt__researcher_1_1retrievers_1_1tavily_1_1tavily__search.html", "namespacegpt__researcher_1_1retrievers_1_1tavily_1_1tavily__search" ]
];