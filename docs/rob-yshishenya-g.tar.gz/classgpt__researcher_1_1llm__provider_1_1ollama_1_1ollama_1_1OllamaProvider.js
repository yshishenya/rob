var classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider =
[
    [ "__init__", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#a97b824af8393105e35c94f351d9228eb", null ],
    [ "get_base_url", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#abaa5642f4e4df0315f8ee291cebfb338", null ],
    [ "get_chat_response", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#abca636c4eebeec620a4392555613ff9b", null ],
    [ "get_llm_model", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#ab60b0d1083b153b47fb6336a914edbe3", null ],
    [ "stream_response", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#acc5ec4a2e770daf8a88b0e41ee044c04", null ],
    [ "base_url", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#a7adaf9267389bec080606d2a4a1bf477", null ],
    [ "llm", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#a8c2509e16a319613e2142a5e78164e3b", null ],
    [ "max_tokens", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#a27d45ca589ace704c67a3192039fe0e7", null ],
    [ "model", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#ab847ab673b47eff2b2668b17d1e409b9", null ],
    [ "temperature", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html#a75ef1fe2b40db6e77bea1efe8598e738", null ]
];