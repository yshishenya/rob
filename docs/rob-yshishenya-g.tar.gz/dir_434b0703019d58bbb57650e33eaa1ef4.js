var dir_434b0703019d58bbb57650e33eaa1ef4 =
[
    [ "utils", "dir_a24b43acf419029ff7cae0fd96806de7.html", "dir_a24b43acf419029ff7cae0fd96806de7" ],
    [ "__init__.py", "multi__agents_2agents_2____init_____8py.html", "multi__agents_2agents_2____init_____8py" ],
    [ "editor.py", "editor_8py.html", "editor_8py" ],
    [ "master.py", "master_8py.html", "master_8py" ],
    [ "publisher.py", "publisher_8py.html", "publisher_8py" ],
    [ "researcher.py", "researcher_8py.html", "researcher_8py" ],
    [ "reviewer.py", "reviewer_8py.html", "reviewer_8py" ],
    [ "reviser.py", "reviser_8py.html", "reviser_8py" ],
    [ "writer.py", "writer_8py.html", "writer_8py" ]
];