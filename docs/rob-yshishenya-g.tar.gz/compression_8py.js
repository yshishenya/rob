var compression_8py =
[
    [ "gpt_researcher.context.compression.ContextCompressor", "classgpt__researcher_1_1context_1_1compression_1_1ContextCompressor.html", "classgpt__researcher_1_1context_1_1compression_1_1ContextCompressor" ]
];