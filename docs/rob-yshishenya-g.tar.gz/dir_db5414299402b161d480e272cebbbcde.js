var dir_db5414299402b161d480e272cebbbcde =
[
    [ "__init__.py", "gpt__researcher_2memory_2____init_____8py.html", null ],
    [ "embeddings.py", "embeddings_8py.html", "embeddings_8py" ]
];