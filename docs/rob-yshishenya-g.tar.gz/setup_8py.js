var setup_8py =
[
    [ "author", "setup_8py.html#a3a57a4772d418a06835249cbade0d86a", null ],
    [ "author_email", "setup_8py.html#a5b08034343aa2be607722a8b315f3625", null ],
    [ "classifiers", "setup_8py.html#abe96a9c38c1c61f9f0fdb002c482f785", null ],
    [ "description", "setup_8py.html#aedf461ec52a946bda975938ba0b93ec0", null ],
    [ "encoding", "setup_8py.html#a443be2d01fd539bf6761aff70724d876", null ],
    [ "install_requires", "setup_8py.html#abead4f26b530856f858f0d44c7cf2588", null ],
    [ "license", "setup_8py.html#a8ed6f50a28bd6a8794f8e1153baa6de9", null ],
    [ "long_description", "setup_8py.html#a4cda9dbfb952875376a0749fe08a5bde", null ],
    [ "long_description_content_type", "setup_8py.html#a3796ea10c998699d07d391414ff5d720", null ],
    [ "name", "setup_8py.html#ab3a7a0638d76a01367c5bc3cc699447f", null ],
    [ "package_dir", "setup_8py.html#afd7273d426fd6e1796ec17175f6521c3", null ],
    [ "packages", "setup_8py.html#aff2375a361fd5865c77bd9aa093be747", null ],
    [ "reqs", "setup_8py.html#a0c3c621ddfb4bf8d8bc8d7368f4e272a", null ],
    [ "url", "setup_8py.html#afc13124aa5c0124e84e1d965e3f4b0fb", null ],
    [ "version", "setup_8py.html#a2aa722b36a933088812b50ea79b97a5c", null ]
];