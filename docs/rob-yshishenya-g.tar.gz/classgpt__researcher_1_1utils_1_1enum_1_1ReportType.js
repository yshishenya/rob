var classgpt__researcher_1_1utils_1_1enum_1_1ReportType =
[
    [ "CustomReport", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#a504d1981defb724d1b01a57c6c9bebb6", null ],
    [ "DetailedReport", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#af840c0b75b47688f7af4e19d525deffe", null ],
    [ "OutlineReport", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#aac580d69ab16f89917b617b4fe255e5f", null ],
    [ "ResearchReport", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#abc97d8a9af5c1c3f0e36ba370f7bd084", null ],
    [ "ResourceReport", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#a7127e98d2b356dd6499b5f69938bd197", null ],
    [ "SubtopicReport", "classgpt__researcher_1_1utils_1_1enum_1_1ReportType.html#a5c591d99b5639a39b86e1c723b7a1014", null ]
];