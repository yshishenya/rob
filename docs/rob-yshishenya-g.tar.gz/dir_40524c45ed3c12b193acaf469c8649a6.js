var dir_40524c45ed3c12b193acaf469c8649a6 =
[
    [ "__init__.py", "scraping_2processing_2____init_____8py.html", null ],
    [ "html.py", "html_8py.html", "html_8py" ],
    [ "text.py", "text_8py.html", "text_8py" ]
];