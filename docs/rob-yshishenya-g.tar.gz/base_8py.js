var base_8py =
[
    [ "gpt_researcher.llm_provider.generic.base.GenericLLMProvider", "classgpt__researcher_1_1llm__provider_1_1generic_1_1base_1_1GenericLLMProvider.html", "classgpt__researcher_1_1llm__provider_1_1generic_1_1base_1_1GenericLLMProvider" ],
    [ "_check_pkg", "base_8py.html#a35c9d5a74d44f148fdd6879bc9b82f86", null ],
    [ "_SUPPORTED_PROVIDERS", "base_8py.html#a9f6d46c37d23d8d132a407cb13f5f821", null ]
];