var dir_dae0667084c4390d618a3a4e85c2e33d =
[
    [ "__init__.py", "backend_2report__type_2detailed__report_2____init_____8py.html", null ],
    [ "detailed_report.py", "detailed__report_8py.html", "detailed__report_8py" ]
];