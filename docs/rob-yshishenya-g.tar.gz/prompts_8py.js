var prompts_8py =
[
    [ "auto_agent_instructions", "prompts_8py.html#a1b8b6bf3d2fe1f56795cf36c745c9545", null ],
    [ "generate_custom_report_prompt", "prompts_8py.html#a32d1e3b87f76b16c6934959abc348ec0", null ],
    [ "generate_outline_report_prompt", "prompts_8py.html#a250d14916f8487c0a0a5959322e51b10", null ],
    [ "generate_report_introduction", "prompts_8py.html#a5ab2bf457ff727dc200a27395b0b05c8", null ],
    [ "generate_report_prompt", "prompts_8py.html#aa1acdb319226c2434745dd28ddc12a13", null ],
    [ "generate_resource_report_prompt", "prompts_8py.html#a076ce149c880d13d4702ff92da83d7f5", null ],
    [ "generate_search_queries_prompt", "prompts_8py.html#a1515d26ed2febbb7bb2670723e9bc3c7", null ],
    [ "generate_subtopic_report_prompt", "prompts_8py.html#afe484ac6f9c1a55a54a9b2add561ff4d", null ],
    [ "generate_subtopics_prompt", "prompts_8py.html#afa1a6e6fa275aa54ca3cf6f5030d5f8e", null ],
    [ "generate_summary_prompt", "prompts_8py.html#aa624fb10f7c23dd338e53222a0de584c", null ],
    [ "get_prompt_by_report_type", "prompts_8py.html#abb901630f113e1efe4c635c5f6e8229c", null ],
    [ "get_report_by_type", "prompts_8py.html#ab0519037b4c15adb99ff3dd89076c9e9", null ],
    [ "report_type_mapping", "prompts_8py.html#aaffdcbce2b4c96cc4fc6f8bb4411bc23", null ]
];