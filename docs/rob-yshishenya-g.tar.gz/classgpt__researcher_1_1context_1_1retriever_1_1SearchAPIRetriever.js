var classgpt__researcher_1_1context_1_1retriever_1_1SearchAPIRetriever =
[
    [ "_get_relevant_documents", "classgpt__researcher_1_1context_1_1retriever_1_1SearchAPIRetriever.html#ad348c38878f9d19adb17a5c7a88318a8", null ],
    [ "pages", "classgpt__researcher_1_1context_1_1retriever_1_1SearchAPIRetriever.html#a403976a777ded595557dda0b9bca2cad", null ]
];