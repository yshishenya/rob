var namespacegpt__researcher_1_1retrievers_1_1tavily_1_1tavily__search =
[
    [ "TavilySearch", "classgpt__researcher_1_1retrievers_1_1tavily_1_1tavily__search_1_1TavilySearch.html", "classgpt__researcher_1_1retrievers_1_1tavily_1_1tavily__search_1_1TavilySearch" ]
];