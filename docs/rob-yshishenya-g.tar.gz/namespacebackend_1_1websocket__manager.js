var namespacebackend_1_1websocket__manager =
[
    [ "WebSocketManager", "classbackend_1_1websocket__manager_1_1WebSocketManager.html", "classbackend_1_1websocket__manager_1_1WebSocketManager" ],
    [ "run_agent", "namespacebackend_1_1websocket__manager.html#ad5e0c8aa0f181850975a175494cab870", null ]
];