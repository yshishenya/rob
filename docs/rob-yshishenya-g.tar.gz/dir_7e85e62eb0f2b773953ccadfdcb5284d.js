var dir_7e85e62eb0f2b773953ccadfdcb5284d =
[
    [ "processing", "dir_40524c45ed3c12b193acaf469c8649a6.html", "dir_40524c45ed3c12b193acaf469c8649a6" ],
    [ "scrape_skills.py", "scrape__skills_8py.html", "scrape__skills_8py" ],
    [ "web_scrape.py", "web__scrape_8py.html", "web__scrape_8py" ]
];