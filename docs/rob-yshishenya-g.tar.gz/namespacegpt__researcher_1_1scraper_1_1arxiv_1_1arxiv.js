var namespacegpt__researcher_1_1scraper_1_1arxiv_1_1arxiv =
[
    [ "ArxivScraper", "classgpt__researcher_1_1scraper_1_1arxiv_1_1arxiv_1_1ArxivScraper.html", "classgpt__researcher_1_1scraper_1_1arxiv_1_1arxiv_1_1ArxivScraper" ]
];