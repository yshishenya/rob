var dir_cf8b1aeaeeffac060219f334b3e4f4a5 =
[
    [ "__init__.py", "gpt__researcher_2scraper_2web__base__loader_2____init_____8py.html", null ],
    [ "web_base_loader.py", "web__base__loader_8py.html", "web__base__loader_8py" ]
];