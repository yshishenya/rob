var dir_20a3dd4fa931084554e397067fac6117 =
[
    [ "arxiv", "dir_c2322bc8ce27c479ab1e70b3921bfaa8.html", "dir_c2322bc8ce27c479ab1e70b3921bfaa8" ],
    [ "beautiful_soup", "dir_93c3e6444ead30d4602574fa7e788534.html", "dir_93c3e6444ead30d4602574fa7e788534" ],
    [ "newspaper", "dir_6cc4a516d36966cf3b002e9417ad9c20.html", "dir_6cc4a516d36966cf3b002e9417ad9c20" ],
    [ "pymupdf", "dir_f226f89b749fe429606d1d77bcfbafe2.html", "dir_f226f89b749fe429606d1d77bcfbafe2" ],
    [ "web_base_loader", "dir_cf8b1aeaeeffac060219f334b3e4f4a5.html", "dir_cf8b1aeaeeffac060219f334b3e4f4a5" ],
    [ "__init__.py", "gpt__researcher_2scraper_2____init_____8py.html", "gpt__researcher_2scraper_2____init_____8py" ],
    [ "scraper.py", "scraper_8py.html", "scraper_8py" ]
];