var all_6_report_types_8py =
[
    [ "test_gpt_researcher", "all-6-report-types_8py.html#a6abdc0949357efb3cff7dcd30cb59853", null ],
    [ "output_dir", "all-6-report-types_8py.html#a5c73a537ae3b6ea0c356f98c9d74ae11", null ],
    [ "query", "all-6-report-types_8py.html#a270c2acc29395cbfe0b575874b4618ac", null ],
    [ "report_types", "all-6-report-types_8py.html#aecb9c0531cfe93f14038ec0441771f16", null ],
    [ "sources", "all-6-report-types_8py.html#a198e412432762cd75d1e0eb0c73f246d", null ]
];