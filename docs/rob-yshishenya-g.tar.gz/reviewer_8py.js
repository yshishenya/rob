var reviewer_8py =
[
    [ "agents.reviewer.ReviewerAgent", "classagents_1_1reviewer_1_1ReviewerAgent.html", "classagents_1_1reviewer_1_1ReviewerAgent" ],
    [ "TEMPLATE", "reviewer_8py.html#abac832073d6b2b703c15ee2ea425dcee", null ]
];