var documents_report_source_8py =
[
    [ "test_gpt_researcher", "documents-report-source_8py.html#ad12a9b38a596a55ac62431fe1116e367", null ],
    [ "output_dir", "documents-report-source_8py.html#af938f99fc526afa847916a04f53f20e7", null ],
    [ "query", "documents-report-source_8py.html#adde104a314af0f4c17bc4c902abf5857", null ],
    [ "report_types", "documents-report-source_8py.html#abe193fbaff482c0f4acb6195464e2bd2", null ]
];