var classauth_1_1PasswordChangeRequest =
[
    [ "new_password", "classauth_1_1PasswordChangeRequest.html#af2b477dc79860feb9599c65f4b203883", null ],
    [ "user_id", "classauth_1_1PasswordChangeRequest.html#a7c159aa9496534e7ff01dd9ad6990115", null ]
];