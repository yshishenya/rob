var namespaceagents =
[
    [ "editor", "namespaceagents_1_1editor.html", "namespaceagents_1_1editor" ],
    [ "master", "namespaceagents_1_1master.html", "namespaceagents_1_1master" ],
    [ "publisher", "namespaceagents_1_1publisher.html", "namespaceagents_1_1publisher" ],
    [ "researcher", "namespaceagents_1_1researcher.html", "namespaceagents_1_1researcher" ],
    [ "reviewer", "namespaceagents_1_1reviewer.html", "namespaceagents_1_1reviewer" ],
    [ "reviser", "namespaceagents_1_1reviser.html", "namespaceagents_1_1reviser" ],
    [ "utils", "namespaceagents_1_1utils.html", "namespaceagents_1_1utils" ],
    [ "writer", "namespaceagents_1_1writer.html", "namespaceagents_1_1writer" ],
    [ "__all__", "namespaceagents.html#a81c46b0f706b9874f61e90dde4d4bf12", null ]
];