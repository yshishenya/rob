var namespacememory =
[
    [ "draft", "namespacememory_1_1draft.html", "namespacememory_1_1draft" ],
    [ "research", "namespacememory_1_1research.html", "namespacememory_1_1research" ]
];