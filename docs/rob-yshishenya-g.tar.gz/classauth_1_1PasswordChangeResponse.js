var classauth_1_1PasswordChangeResponse =
[
    [ "message", "classauth_1_1PasswordChangeResponse.html#ac11ab832f1e396de0e0a6a46c4ce68e9", null ],
    [ "user_id", "classauth_1_1PasswordChangeResponse.html#a1b671df6ae3def36be8b605f1f0e6b67", null ]
];