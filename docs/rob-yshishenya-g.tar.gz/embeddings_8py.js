var embeddings_8py =
[
    [ "gpt_researcher.memory.embeddings.Memory", "classgpt__researcher_1_1memory_1_1embeddings_1_1Memory.html", "classgpt__researcher_1_1memory_1_1embeddings_1_1Memory" ],
    [ "OPENAI_EMBEDDING_MODEL", "embeddings_8py.html#acba50864a73b23ad689f762c7805e8cd", null ]
];