var ollama_8py =
[
    [ "gpt_researcher.llm_provider.ollama.ollama.OllamaProvider", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider.html", "classgpt__researcher_1_1llm__provider_1_1ollama_1_1ollama_1_1OllamaProvider" ]
];