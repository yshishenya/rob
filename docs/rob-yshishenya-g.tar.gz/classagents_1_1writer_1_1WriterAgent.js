var classagents_1_1writer_1_1WriterAgent =
[
    [ "__init__", "classagents_1_1writer_1_1WriterAgent.html#aeed8e40ea98de396d419386d28507e1b", null ],
    [ "get_headers", "classagents_1_1writer_1_1WriterAgent.html#afe89553ca1031e9847522ea8a945f50a", null ],
    [ "revise_headers", "classagents_1_1writer_1_1WriterAgent.html#a1fc2cc02dd6d702e2d3599086f26dc8f", null ],
    [ "run", "classagents_1_1writer_1_1WriterAgent.html#aeea35fc6e190669f99d20c20409fc266", null ],
    [ "write_sections", "classagents_1_1writer_1_1WriterAgent.html#ad090d0934f61168407dec03c5c9eae4d", null ]
];