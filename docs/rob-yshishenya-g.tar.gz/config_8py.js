var config_8py =
[
    [ "gpt_researcher.config.config.Config", "classgpt__researcher_1_1config_1_1config_1_1Config.html", "classgpt__researcher_1_1config_1_1config_1_1Config" ]
];