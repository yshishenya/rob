var namespacegpt__researcher_1_1scraper_1_1pymupdf_1_1pymupdf =
[
    [ "PyMuPDFScraper", "classgpt__researcher_1_1scraper_1_1pymupdf_1_1pymupdf_1_1PyMuPDFScraper.html", "classgpt__researcher_1_1scraper_1_1pymupdf_1_1pymupdf_1_1PyMuPDFScraper" ]
];